//
//  SecondViewController.swift
//  SegueApp
//
//  Created by Nigar ESRA KIN on 5.11.2022.
//

import UIKit

class SecondViewController: UIViewController {

    @IBOutlet weak var myLabelSecond: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    


}
