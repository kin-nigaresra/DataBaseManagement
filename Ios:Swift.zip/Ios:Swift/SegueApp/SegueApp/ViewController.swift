//
//  ViewController.swift
//  SegueApp
//
//  Created by Nigar ESRA KIN on 5.11.2022.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var myLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

