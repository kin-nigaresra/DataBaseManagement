import UIKit

// OPSIYONELLER

var myName : String = "james"
myName.uppercased()

// burada eğer james olarak değer tanımlamasaydım uppercased fonksiyonu çalışmazdı.
// aşağıdaki gibi soru işaret koymak bunu opsiyonel yap anlamına geliyor. myName? ise ben belki isim veririm belki vermem eğer verirsem işlemi gerçekleştir anlamında kullanılıyor.


//var myName : String?
//myName?.uppercased()

// var myName : String?
// myName!.uppercased() buradaki myName! ise değer kesinlikle gelecek anlamına gelir.

// Optionals: ? vs !

var myAge = "rr"
var myInteger = (Int(myAge) ?? 0) * 5
if let myNumber = Int(myAge) {
    print(myNumber)
} else {
    print("wrong input")
}
// 25. ders videosu opsiyoneller bir daha tekrar etmek gerekebilir!

