//
//  main.swift
//  CommandLineVariables
//
//  Created by Nigar ESRA KIN on 10.10.2022.
//

import Foundation
print("Hello, World!")

var myNumber = 4*4
print(myNumber)

