import UIKit

var myNumber = 1
myNumber = myNumber + 1
myNumber += 1


var number = 0
// While Loop

while number < 10 {
    print(number)
    number += 1
}


// FOR LOOP

var myFruitArray = ["banana", "apple", "orange"]

for fruit in myFruitArray {
    print(fruit)
}


var myNumbers = [10, 20, 30, 40, 50, 60]

for number in myNumbers {
    print(number / 5)
}


for mynewinteger in 1 ... 5 {
    print(mynewinteger)
}


var fibonacciArray = [1,1,2,3,5,8,13]

for num in fibonacciArray {
    
    let myNum = num * 5
    print(myNum)
}
