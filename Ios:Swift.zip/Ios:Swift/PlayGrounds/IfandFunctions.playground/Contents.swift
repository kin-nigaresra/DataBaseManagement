import UIKit

var myAge = 32

// AND &&
// OR ||

if myAge < 30 {
    print("30-")
} else if myAge > 30 && myAge < 40 {
    print("30s")
} else {
    print("40+")
}


// Functions

func myFunction() {
    print("my function")
}
myFunction()

// Input && Output && Return

// Return işlemini yapabilmek için -> Int yapıyoruz.
// bir şey döndürmeyeceği durumda ise fonksiyon "Void" olarak gözükür yani boş anlamına gelir.

//func sumFunction(x: Int, y:Int) {
    //print(x+y)
//}
//sumFunction(x:10, y:20)

func sumFunction(x:Int, y:Int) -> Int {
    return x+y
}
sumFunction(x: 10, y: 20)

let myFunctionVariable = sumFunction(x: 10, y: 20)
print(myFunctionVariable)

func logicFunction(a:Int, b:Int) -> Bool {
    if a > b {
        return true
    } else {
        return false
    }
}
logicFunction(a: 15, b: 9)
