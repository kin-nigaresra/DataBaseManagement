import UIKit

// Variables and Constants

// snake_case
// camelCase
// kodlar sırası ile çalıştırılır!


// PART 1

var userName = "Recep"
userName.append("toş")
userName.lowercased()
userName.uppercased()

var userSurname = "Bozdemir"

userName = "Dilara"
print(userName)

// let ile constants (sabitler) oluştururuz. değiştirilemezler,
// (immutable)
let userAge = 50.0
let pi = 3.14
userAge * pi

// integer
let myAge = 25
let myNumber = 4
myAge / myNumber
// burada görüldüğü gibi sabitlerde integer / integer olduğu zaman, küsüratı almıyor integer sayı yani tam sayı sonucunu çıkarıyor

// double
let myAgeD = 45.0
let myNumberD = 6.0
myAgeD / myNumberD

// boolean
var myBoolean = false
myBoolean = true


// PART 2

let myString : String = "50"
let anotherNumber: Int = 10

let stringNumber = String(20)

// define (tanımlamak)
let myVariable : String

// intialization (başlatmak)
myVariable = "Test"
myVariable.uppercased()

let myUpperVariable = myVariable.uppercased()
print(myUpperVariable)
print(myVariable)
// bir değişkeni tanımlamakla başlatmak aynı şey değil.
