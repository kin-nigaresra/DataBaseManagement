import UIKit

// table view
// heterogenous collection
// homogenous collection


// ARRAY

var myFavoriteMovies = ["Pulp Fiction", "Kill Bill", "Reservoir Dogs", 5, true] as [Any]
// as --> casting (bir şeyi bir şey gibi ata anlamına gelir)
// myFavoriteMovies'ı herhangi bir obje dizisi gibi ata anlamına geliyor
// any --> any object


// index
myFavoriteMovies[0]
myFavoriteMovies[1]
myFavoriteMovies[2]
myFavoriteMovies[3]
myFavoriteMovies[4]

var myStringArray = ["Test", "Test2", "Test3"]

myStringArray[0].uppercased()
myStringArray.count
myStringArray[myStringArray.count - 1]
myStringArray.last
myStringArray.sort()


let fruitArray = ["elma", "armut", "seftali", "muz"]
fruitArray[2]


// SET
//dizi gibi ama indexleme yok ve içinde aynı elemandan bir tane olabilir, elemanlar unique
// set'lere unordered collection (sırasız koleksiyon) denir.

var mySet : Set = [1,2,3,4,5]

var myInternetArray = [1,2,3,1,2,5,6,2,1]
var myInternetSet = Set(myInternetArray)
print(myInternetArray)
print(myInternetSet)


var mySet1 : Set = [1,2,3]
var mySet2 : Set = [3,4,5]

var mySet3 = mySet1.union(mySet2)
print(mySet3)


// DICTIONARY
// key-value pairing  (anahtar ve değer eşleşmesi)

var myFavoriteDirectors = ["Pulp Fiction": "Tarantino", "Lock Stock": "Guy Ritchie", "The Dark Night": "Christopher Nolan"]
myFavoriteDirectors["Pulp Fiction"]
myFavoriteDirectors["The Dark Night"]

myFavoriteDirectors["The Dark Night"] = "The Dark Knight"

print(myFavoriteDirectors)
