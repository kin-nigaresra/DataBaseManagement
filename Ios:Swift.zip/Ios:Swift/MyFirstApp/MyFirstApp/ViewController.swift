//
//  ViewController.swift
//  MyFirstApp
//
//  Created by Nigar ESRA KIN on 8.10.2022.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var BridgertonLabel: UILabel!
    
    @IBOutlet weak var imageView: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func changeClicked(_ sender: Any) {
        imageView.image = UIImage(named: "bridgerton2")
    }
    
}

