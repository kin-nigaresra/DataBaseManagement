//
//  ViewController.swift
//  Simple Calculator
//
//  Created by Nigar ESRA KIN on 15.10.2022.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var FirstText: UITextField!
    
    @IBOutlet weak var SeconText: UITextField!
    
    
    @IBOutlet weak var resultLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func sumClicked(_ sender: Any) {
        if let firstNumber = Int(FirstText.text!) {
            if let secondNumber = Int(SeconText.text!) {
                
                let result = firstNumber + secondNumber
                resultLabel.text = String(result)
                
            }
        }
    }
    
    @IBAction func minusClicked(_ sender: Any) {
        if let firstNumber = Int(FirstText.text!) {
            if let secondNumber = Int(SeconText.text!) {
                
                let result = firstNumber - secondNumber
                resultLabel.text = String(result)
                
            }
        }
    }
    
    @IBAction func multiplyClicked(_ sender: Any) {
        if let firstNumber = Int(FirstText.text!) {
            if let secondNumber = Int(SeconText.text!) {
                
                let result = firstNumber * secondNumber
                resultLabel.text = String(result)
                
            }
        }
    }
    
    @IBAction func dividedClicked(_ sender: Any) {
        if let firstNumber = Int(FirstText.text!) {
            if let secondNumber = Int(SeconText.text!) {
                
                let result = firstNumber / secondNumber
                resultLabel.text = String(result)
                
            }
        }
    }
    
    
    
}

